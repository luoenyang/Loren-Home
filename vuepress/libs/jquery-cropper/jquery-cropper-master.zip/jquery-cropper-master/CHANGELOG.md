# Changelog

## 1.0.1 (Oct 19, 2019)

- Register as a plugin only when both the jQuery and Cropper.js are existing.

## 1.0.0 (Apr 1, 2018)

- Just released as a stable version.

## 1.0.0-beta (Mar 3, 2018)

- Release the beta version.

## 1.0.0-alpha (Feb 28, 2018)

- Init.
